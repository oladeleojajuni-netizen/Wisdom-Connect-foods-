import 'react-native-url-polyfill/auto';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {createClient} from '@supabase/supabase-js';
const url=process.env.EXPO_PUBLIC_SUPABASE_URL;
const key=process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;
export const cloudEnabled=process.env.EXPO_PUBLIC_ENABLE_CLOUD!=='false'&&Boolean(url&&key&&!url.includes('YOUR_PROJECT')&&!key.includes('YOUR_'));
export const supabase=cloudEnabled?createClient(url!,key!,{auth:{storage:AsyncStorage,autoRefreshToken:true,persistSession:true,detectSessionInUrl:false}}):null;
